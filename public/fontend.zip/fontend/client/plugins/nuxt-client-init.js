export default (ctx) => {
  ctx.store.dispatch('nuxtClientInit', ctx)
}
