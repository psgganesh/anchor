<template>
    <div class="layout">
        <div class="container-fluid">
            <nuxt/>
        </div>
    </div>
</template>

<script>
export default {
}
</script>
