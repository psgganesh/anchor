# nuxtJS client

> Anchor front-end

## Build Setup

``` bash
# install dependencies
$ npm install
$ npm run build
```

For detailed explanation on how things work, checkout [Nuxt.js docs](https://nuxtjs.org).
